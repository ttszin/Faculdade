This is a starter project for the [Chris Courses Online Multiplayer Game Tutorial](https://www.youtube.com/watch?v=Wcvqnx14cZA) available on YouTube.

To get started, download this repo and double click `index.html` to see the single-player game we'll base our multiplayer-game off of.
